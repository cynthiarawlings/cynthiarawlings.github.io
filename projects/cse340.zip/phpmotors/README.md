# PHP Motors Created By Cynthia Rawlings

PHP Motors is a LAMP stack project utilizing XAMPP to run Apache and the database server.

Programming languages used: PHP, MySQL, HTML, CSS, and JavaScript

This project uses an MVC architecture. 
