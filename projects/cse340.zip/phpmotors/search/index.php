<?php
// This is the search controller

// Create or access a Session
session_start();

// Get the database connection file
require_once '../library/connections.php';
// Get the PHP Motors model for use as needed
require_once '../model/main-model.php';
// Get the accounts model
require_once '../model/accounts-model.php';
// Get the functions library
require_once '../library/functions.php';
// get the search model
require_once '../model/search-model.php';

// Check if the firstname cookie exists, get its value
if(isset($_COOKIE['firstname'])){
    $cookieFirstname = filter_input(INPUT_COOKIE, 'firstname', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
    $cookieEmail = filter_input(INPUT_COOKIE, 'email', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

    $clientEmail = $cookieEmail;

    $clientData = getClient($clientEmail);
    array_pop($clientData);
    $_SESSION['clientData'] = $clientData;
    $_SESSION['loggedin'] = True;

    $clientFirstname = $clientData['clientFirstname'];

    setcookie('firstname', $clientFirstname, strtotime('+1 year'), '/');
    setcookie('email', $clientEmail, strtotime('+1 year'), '/');
}

// Get the array of classifications
$classifications = getClassifications();
$navList = buildNavList($classifications);


$action = filter_input(INPUT_GET, 'action');
if ($action == NULL) {
    $action = filter_input(INPUT_POST, 'action');
}

switch ($action) {
    case 'search':
        if (isset($_SESSION['searchTerm'])) {
            $_SESSION['searchTerm'].session_unset();
        }
        include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/view/search.php';
    break;

    case 'beginSearch':
        // This escapes all the special characters so they don't effect the search, but they still show up in the search bar.
        $searchTerm = strtolower(trim(htmlspecialchars($_POST['searchTerm'], ENT_QUOTES)));

        if (empty($searchTerm)) {
            $_SESSION['message'] = 'Please enter a Make, Model, Color, Price, ect.';
            include '../view/search.php';
            exit;
        }

        // Remove the $ so numbers can be searched better
        if ($searchTerm[0] == "$") {
            $searchTerm = substr($searchTerm, 1);
        }

        $_SESSION['searchTerm'] = $searchTerm;

        $AllSearchResults = [];

        // I indexed make and price in phpmyadmin

        // Search Make
        $searchResults = searchMake($searchTerm);
        if (count($searchResults) > 0) {
            $AllSearchResults = array_merge($AllSearchResults, $searchResults);
        }
       
        // // Search Model
        $searchResults = searchModel($searchTerm);
        if (count($searchResults) > 0) {
            $AllSearchResults = array_merge($AllSearchResults, $searchResults);
        }
        // Search Classification
        $searchedClassificationId = getClassificationId($searchTerm);
        $searchResults = searchClassification($searchedClassificationId);
        if (count($searchResults) > 0) {
            $AllSearchResults = array_merge($AllSearchResults, $searchResults);
        }
        // // Search Description
        $searchResults = searchDescription($searchTerm);
        if (count($searchResults) > 0) {
            $AllSearchResults = array_merge($AllSearchResults, $searchResults);
        }
        // Search Color
        $searchResults = searchColor($searchTerm);
        if (count($searchResults) > 0) {
            $AllSearchResults = array_merge($AllSearchResults, $searchResults);
        }
        // Search Price
      
        // The search will return everything within $5,000 above and below
        $int_searchTerm = intval($searchTerm);

        $searchResults = searchPrice($int_searchTerm);
        if (count($searchResults) > 0) {
            $AllSearchResults = array_merge($AllSearchResults, $searchResults);
        }
        // Search Miles
        // The search will return everything within $15,000 above and below
        $searchResults = searchMiles($int_searchTerm);
        if (count($searchResults) > 0) {
            $AllSearchResults = array_merge($AllSearchResults, $searchResults);
        }
        // Search Year
        $searchResults = searchYear($int_searchTerm);
        if (count($searchResults) > 0) {
            $AllSearchResults = array_merge($AllSearchResults, $searchResults);
        }
        
        $ids = [];

        // Adds the Id to a array of ids so it is no longer a multidimensional array
        foreach ($AllSearchResults as $result) {
            array_push($ids, $result['invId']);
        }

        // Filters and sorts the ids so the one with the most result hits comes first
        $values = array_count_values($ids);
        arsort($values);
        $sortedIds = array_keys($values);

        

        $vehicles = [];
        foreach ($sortedIds as $invId) {
            $vehicle = getInvItemInfo($invId);
            // When "White" is searched there is a blank result because of a duplicate in the table
            // with a different id. To fix this, I check if results were returned before adding them.
            if ($vehicle) {
                array_push($vehicles, $vehicle);
            }
        }

        // Counts the number of results after the duplicates are removed
        $count_results = count($vehicles);

   
        $current_page = 1;

        if (count($vehicles) > 10) {
            // $num_pages = round(count($vehicles) / 10) + 1;
            $count = count($vehicles);
            $num_pages = 0;
            while ($count > 0) {
                $num_pages += 1;
                $count -= 10;
            }

            $_SESSION['vehicles'] = $vehicles;
            $_SESSION['num_pages'] = $num_pages;
            $_SESSION['current_page'] = $current_page;

            $current_vehicles = array_slice($vehicles, 0, 10);

            $resultBox = display10Results($current_vehicles, $num_pages, $current_page);

        }
        else {
            $resultBox = displayResults($vehicles);
        }
        
        
        include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/view/search.php';

    break;

    case 'nextResults':
        $vehicles = $_SESSION['vehicles'];
        $num_pages = $_SESSION['num_pages'];
        $current_page = $_SESSION['current_page'];

        // Counts the number of results after the duplicates are removed
        $count_results = count($vehicles);

        $location = filter_input(INPUT_GET, 'location');
        if ($location == NULL) {
            $location = filter_input(INPUT_POST, 'location');
        }

        $location = intval($location);

        if ($location == NULL) {
            $location = $current_page + 1;
        }

        $end = $location * 10;
        $start = $end - 10;

        $current_vehicles = array_slice($vehicles, $start, 10, true);

        $current_page += 1;

        $resultBox = display10Results($current_vehicles, $num_pages, $current_page);

        // Reset the session variables

        $_SESSION['vehicles'] = $vehicles;
        $_SESSION['num_pages'] = $num_pages;
        $_SESSION['current_page'] = $current_page;

        include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/view/search.php';

    break;

    case 'prevResults':
        $vehicles = $_SESSION['vehicles'];
        $num_pages = $_SESSION['num_pages'];
        $current_page = $_SESSION['current_page'];

        // Counts the number of results after the duplicates are removed
        $count_results = count($vehicles);

        $location = filter_input(INPUT_GET, 'location');
        if ($location == NULL) {
            $location = filter_input(INPUT_POST, 'location');
        }

        $location = intval($location);

        if ($location == NULL) {
            $location = $current_page - 1;
        }

        $end = $location * 10;
        $start = $end - 10;

        $current_vehicles = array_slice($vehicles, $start, 10, true);

        $current_page -= 1;

        $resultBox = display10Results($current_vehicles, $num_pages, $current_page);

        // Reset the session variables

        $_SESSION['vehicles'] = $vehicles;
        $_SESSION['num_pages'] = $num_pages;
        $_SESSION['current_page'] = $current_page;

        include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/view/search.php';

    break;

    default:
        include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/view/search.php';
    break;
}
